import os
from random import randint
from django.core.validators import RegexValidator
phone_regex_validator = RegexValidator(regex=r'^\+?1?\d{9,12}$')
def random_id_generator():
    n = 10
    range_start = 10**(n-1)
    range_end = (10**n)-1
    return randint(range_start, range_end)