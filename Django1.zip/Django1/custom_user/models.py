from django.db import models
from django.contrib.auth.models import _user_has_perm, _user_get_permissions, _user_has_module_perms
from django.contrib.auth.models import (
    BaseUserManager, AbstractBaseUser, PermissionsMixin
)

class CustomersManager(BaseUserManager):
    def create_user(self, email, password=None):
        """
        Creates and saves a User with the given email and password.
        """
        if not email:
            raise ValueError('Users must have a email')

        user = self.model(
            email=self.normalize_email(email)
        )

        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None):
        """
        Creates and saves a superuser with the given email and password.
        """
        user = self.create_user(
            email,
            password=password
        )
        # user.is_staff = True
        user.is_admin = True
        user.is_superuser = True
        user.save(using=self._db)
        return user


GENDER_CHOICES = (
    ('M','Male'),
    ('F','Female'),
)
QUALIFICATION_CHOICES = (
    (1, 'B.Tech'),
    (2, 'B.CA'),
    (3, 'M.CA'),
    (4, 'MBA'),
    (5, 'B.Com'),
    (6, 'B.Sc'),
)
USER_ROLE_CHOICES = (
    (1, 'User'),
    (2, 'Staff'),
    (3, 'Alumni'),
)

from django.core.validators import RegexValidator

phone_regex_validator = RegexValidator(regex=r'^\+?1?\d{9,12}$')

class Customer(PermissionsMixin, AbstractBaseUser):
    profile_photo = models.FileField(upload_to="users_profiles/", null=True, blank=True)
    first_name = models.CharField(max_length=50, default="", null=False, blank=False)
    last_name = models.CharField(max_length=50, default="", null=False, blank=False)
    phone_number = models.CharField(validators=[phone_regex_validator], max_length=12, null=False, blank=False)
    email = models.EmailField(verbose_name='email address', max_length=255, unique=True)
    is_admin = models.BooleanField(default=False)
    dob = models.DateField(null=True, blank=True)
    gender = models.CharField(default='M',max_length=1,choices=GENDER_CHOICES)
    qualification = models.IntegerField(default=1, choices=QUALIFICATION_CHOICES)
    address=models.CharField(default="",max_length=50,null=False,blank=False)
    is_active = models.BooleanField(default=True)
    role_id = models.IntegerField(default=1, choices=USER_ROLE_CHOICES)
    is_superuser = models.BooleanField(default=False)
    date_joined = models.DateTimeField(auto_now_add=True)

    objects = CustomersManager()

    USERNAME_FIELD = 'email'

    def __str__(self): 
        return str(self.email)

    def get_address(self):
        return str(self.address)

    def get_full_name(self):
        return self.first_name + " " + self.last_name

    @property
    def is_staff(self):
        "Is the user a member of staff?"
        # Simplest possible answer: All admins are staff
        return self.is_admin or self.role_id == 2 or self.role_id == 3

    class Meta:
        verbose_name_plural = "Customers"

