# -----------------------------------------------
from django.contrib import admin
from custom_user.models import Customer
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.admin.options import ModelAdmin
from django.core.exceptions import PermissionDenied
from django.contrib.auth.backends import ModelBackend

class CustomerAdmin(BaseUserAdmin, ModelBackend):
    list_display = ('email','profile_photo', 'first_name', 'last_name', 'phone_number','is_admin','dob','gender','qualification','address','is_active','role_id','is_superuser','date_joined')
    list_filter = ('email', 'first_name', 'last_name', 'phone_number','address')
    fieldsets = (
        (None, {'fields': (('email'), 'password')}),
        ('Personal info', {'fields': ('profile_photo',('first_name', 'last_name'),('phone_number', 'address'),('dob','gender','qualification'),('role_id',))}),
        ('Optional Information', {'classes': ('collapse',), 'fields': ('groups','is_admin','is_active','is_superuser')}),
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'password1', 'password2'),
        }),
        ('Permissions', {'fields': ('role_id',)}),
    )
    search_fields = ('email','phone_number','first_name', 'last_name')
    ordering = ('email',)
    filter_horizontal = ('groups', 'user_permissions',)

    def has_delete_permission(self, request, obj=None):
        """ Only superuser can delete user """
        if request.user.is_superuser:
            return True

    def get_queryset(self, request):
        queryset = super(CustomerAdmin, self).get_queryset(request)
        if not request.user.is_superuser:
            return queryset.filter(email=request.user)
        return queryset 
    

admin.site.register(Customer, CustomerAdmin)
