from django.db.models import signals
from django.dispatch import receiver
from .models import Userlogin
from staff_registration.models import staffreg
from alumni_registration.models import alumnireg

@receiver(signals.post_save, sender=Userlogin)
def when_create_customer(sender, instance, created, **kwargs):
    if created and instance.role_id == 2:
        user = staffreg.objects.create(user_id=instance)
        user.save()
    elif created and instance.role_id == 3:
        user = alumnireg.objects.create(user_id=instance)
        user.save()
    else:
       pass
