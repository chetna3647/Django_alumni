from django.db import models
from common_fun.common import random_id_generator
# Create your models here.

class Userlogin(models.Model):
    GENDER_CHOICES=(
        ('M','Male'),
        ('F','Female'),
    )
    QUALIFICATION_CHOICES=(
        ('1','B.Tech'),
        ('2','B.CA'),
        ('3','M.CA'),
        ('4','MBA'),
        ('5','B.Com'),
        ('6','B.Sc'),
    )
    ROLE_CHOICES=(
        (1,'customer'),
        (2,'staff'),
        (3,'alumni'),
    )

    user_id=models.AutoField(primary_key=True,default=random_id_generator,unique=True)
    role_id=models.IntegerField(default=1,choices=ROLE_CHOICES)
    full_name = models.CharField(max_length=100, default="", null=False, blank=False)
    profile_photo = models.ImageField(upload_to='upload/')
    dob = models.DateField(max_length=8)
    email_id=models.EmailField(verbose_name='email address', max_length=255, unique=True)
    gender = models.CharField(default='M',max_length=1,choices=GENDER_CHOICES)
    contact_no = models.IntegerField()
    qualification=models.CharField(default='1',max_length=1,choices=QUALIFICATION_CHOICES)
    address=models.CharField(default="",max_length=50,null=False,blank=False)
    password=models.CharField(default="",max_length=50)

    def __str__(self):
        return str(self.user_id)


