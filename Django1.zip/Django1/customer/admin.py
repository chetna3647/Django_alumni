from django.contrib import admin

# Register your models here.
from customer.models import Userlogin
class UserAdmin(admin.ModelAdmin):
    list_display = ('user_id','full_name','profile_photo','dob','email_id','gender','contact_no','qualification','address','password')
    list_per_page = 10

admin.site.register(Userlogin,UserAdmin)
