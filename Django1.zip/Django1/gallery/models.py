from django.db import models

# Create your models here.
class gallery(models.Model):
    photo = models.FileField(upload_to="Gallery/", null=True, blank=True)