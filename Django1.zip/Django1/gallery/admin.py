from django.contrib import admin

# Register your models here.
from gallery.models import gallery
class galleryAdmin(admin.ModelAdmin):
    list_display = ['photo']
    list_per_page = 10

admin.site.register(gallery,galleryAdmin)