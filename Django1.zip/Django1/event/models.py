from django.db import models

# Create your models here.
class event(models.Model):
    event_id=models.AutoField(primary_key=True,unique=True)
    event_title=models.CharField(max_length=20)
    event_date=models.DateField(max_length=8)
    event_expiry=models.DateField(max_length=8)
    event_time=models.TimeField()
    event_location=models.CharField(max_length=10)