from django.contrib import admin

# Register your models here.
from event.models import event
class eventAdmin(admin.ModelAdmin):
    list_display = ('event_id','event_title','event_date','event_expiry','event_time','event_location')
    list_per_page = 10

admin.site.register(event,eventAdmin)