from django.db import models
from customer.models import Userlogin

# Create your models here.


class staffreg(models.Model):
    staff_id=models.AutoField(primary_key=True,unique=True)
    user_id=models.ForeignKey(Userlogin, on_delete=models.CASCADE, null=True, blank=True)
    designation=models.CharField(max_length=20,default="", null=True,blank=True)
    dateofjoining=models.DateField(max_length=8,null=True,blank=True)
    created_date=models.DateTimeField(auto_now_add=True)
    updated_date=models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name_plural = "staff reg"

