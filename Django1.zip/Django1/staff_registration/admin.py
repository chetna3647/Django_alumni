from django.contrib import admin

# Register your models here.
from staff_registration.models import staffreg
class staffregAdmin(admin.ModelAdmin):
    list_display = ('user_id','staff_id','designation','dateofjoining','created_date','updated_date')
    list_per_page = 10
    search_fields = ['user_id','staff_id','designation','dateofjoining']

admin.site.register(staffreg,staffregAdmin)