from django.contrib import admin

# Register your models here.
from alumni_registration.models import alumnireg
class alumniregAdmin(admin.ModelAdmin):
    list_display = ('user_id','alumni_id','passoutyear','occupation','region','created_date','updated_date')
    list_per_page = 2

admin.site.register(alumnireg,alumniregAdmin)