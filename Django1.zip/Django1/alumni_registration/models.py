from django.db import models
from customer.models import Userlogin

# Create your models here.
class alumnireg(models.Model):
    user_id=models.ForeignKey(Userlogin, on_delete=models.CASCADE, null=True, blank=True)
    alumni_id=models.AutoField(primary_key=True,unique=True)
    passoutyear=models.IntegerField(null=False)
    occupation=models.CharField(max_length=50,null=False,blank=False)
    region=models.CharField(max_length=10,null=False,blank=False)
    created_date=models.DateTimeField(auto_now_add=True)
    updated_date=models.DateTimeField(auto_now=True) 

    class Meta:
        verbose_name_plural = "alumni reg"